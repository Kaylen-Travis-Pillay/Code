***********************************************************************************
			Welcome to frogs and flies!

    Thank you for chosing to try our game out, we hope you have tons of fun :)



              ====================================================
			        Installation

    Installation of the game is VERY simple. Firstly we need you to run the file
    named "RUN_ME_FIRST.exe". This will allow us to setup everything your computer
    needs. 

    Next you can copy the folder labled "Frogs And Flies" to your Desktop for easy
    access.

    AND YOU ARE DONE! Easy right :)

    Now you can go ahead an run the game { located in the Frogs and Flies folder!}



    Thank you and have fun!