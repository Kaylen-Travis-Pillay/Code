#include <iostream>
#include <Windows.h>
#include "FrogsFliesGameInterface.h"
int main() {
	
	FrogsFliesGameInterface k;
	k.RunGameSoftware();
	 return 0;
}


